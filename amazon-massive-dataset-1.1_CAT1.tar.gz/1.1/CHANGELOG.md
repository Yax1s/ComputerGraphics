## [1.1] - 2022-11-16
- Addition of ca-ES

## [1.0] - 2022-04-20
- Original MASSIVE release
